import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:gromart_customer/AppGlobal.dart';
import 'package:gromart_customer/constants.dart';
import 'package:gromart_customer/main.dart';
import 'package:gromart_customer/model/AddressModel.dart';
import 'package:gromart_customer/model/CurrencyModel.dart';
import 'package:gromart_customer/model/User.dart';
import 'package:gromart_customer/services/FirebaseHelper.dart';
import 'package:gromart_customer/services/helper.dart';
import 'package:gromart_customer/services/localDatabase.dart';
import 'package:gromart_customer/ui/Language/language_choose_screen.dart';
import 'package:gromart_customer/ui/QrCodeScanner/QrCodeScanner.dart';
import 'package:gromart_customer/ui/auth/AuthScreen.dart';
import 'package:gromart_customer/ui/cartScreen/CartScreen.dart';
import 'package:gromart_customer/ui/chat_screen/inbox_driver_screen.dart';
import 'package:gromart_customer/ui/chat_screen/inbox_screen.dart';
import 'package:gromart_customer/ui/cuisinesScreen/CuisinesScreen.dart';
import 'package:gromart_customer/ui/dineInScreen/dine_in_screen.dart';
import 'package:gromart_customer/ui/dineInScreen/my_booking_screen.dart';
import 'package:gromart_customer/ui/gift_card/gift_card_screen.dart';
import 'package:gromart_customer/ui/home/HomeScreen.dart';
import 'package:gromart_customer/ui/home/favourite_item.dart';
import 'package:gromart_customer/ui/home/favourite_restaurant.dart';
import 'package:gromart_customer/ui/mapView/MapViewScreen.dart';
import 'package:gromart_customer/ui/ordersScreen/OrdersScreen.dart';
import 'package:gromart_customer/ui/privacy_policy/privacy_policy.dart';
import 'package:gromart_customer/ui/profile/ProfileScreen.dart';
import 'package:gromart_customer/ui/referral_screen/referral_screen.dart';
import 'package:gromart_customer/ui/searchScreen/SearchScreen.dart';
import 'package:gromart_customer/ui/termsAndCondition/terms_and_codition.dart';
import 'package:gromart_customer/ui/wallet/walletScreen.dart';
import 'package:gromart_customer/userPrefrence.dart';
import 'package:gromart_customer/utils/DarkThemeProvider.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';

enum DrawerSelection {
  Home,
  Wallet,
  dineIn,
  Search,
  Cuisines,
  Cart,
  Profile,
  Orders,
  MyBooking,
  termsCondition,
  privacyPolicy,
  chooseLanguage,
  referral,
  inbox,
  driver,
  Logout,
  LikedRestaurant,
  LikedProduct,
  giftCard
}

class ContainerScreen extends StatefulWidget {
  final User? user;
  final Widget? currentWidget;
  final String? appBarTitle;
  final DrawerSelection? drawerSelection;

  const ContainerScreen(
      {super.key,
      this.user,
      this.currentWidget,
      this.appBarTitle,
      this.drawerSelection});

  // ContainerScreen({Key? key, required this.user, currentWidget, appBarTitle, this.drawerSelection = DrawerSelection.Home})
  //     : this.appBarTitle = appBarTitle ?? 'Home'.tr(),
  //       this.currentWidget = currentWidget ?? HomeScreen(),
  //       super(key: key);

  @override
  _ContainerScreen createState() {
    return _ContainerScreen();
  }
}

class _ContainerScreen extends State<ContainerScreen> {
  var key = GlobalKey<ScaffoldState>();

  late CartDatabase cartDatabase;
  late User user;
  late String _appBarTitle;
  final fireStoreUtils = FireStoreUtils();

  Widget? _currentWidget;
  DrawerSelection? _drawerSelection;

  int cartCount = 0;
  bool? isWalletEnable;

  @override
  void initState() {
    super.initState();
    setCurrency();
    if (widget.user != null) {
      user = widget.user!;
    } else {
      user = new User();
    }

    if (widget.appBarTitle != null) {
      _appBarTitle = widget.appBarTitle.toString();
    } else {
      _appBarTitle = "Home".tr();
    }

    if (widget.drawerSelection != null) {
      _drawerSelection = widget.drawerSelection!;
    } else {
      _drawerSelection = DrawerSelection.Home;
    }

    /// On iOS, we request notification permissions, Does nothing and returns null on Android
    FireStoreUtils.firebaseMessaging.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );

    fireStoreUtils.getplaceholderimage().then((value) {
      AppGlobal.placeHolderImage = value;
    });
  }

  setCurrency() async {
    await FirebaseFirestore.instance
        .collection(Setting)
        .doc("home_page_theme")
        .get()
        .then((value) {
      if (value.exists) {
        setState(() {
          if (widget.currentWidget != null) {
            _currentWidget = widget.currentWidget;
          } else {
            _currentWidget = HomeScreen(user: MyAppState.currentUser);
          }
        });
      }
    });

    await FireStoreUtils().getCurrency().then((value) {
      if (value != null) {
        currencyModel = value;
      } else {
        currencyModel = CurrencyModel(
            id: "",
            code: "USD",
            decimal: 2,
            isactive: true,
            name: "US Dollar",
            symbol: "\$",
            symbolatright: false);
      }
    });

    List<Placemark> placeMarks = await placemarkFromCoordinates(MyAppState.selectedPosotion.location!.latitude, MyAppState.selectedPosotion.location!.longitude);
    country = placeMarks.first.country;

    await FireStoreUtils().getTaxList().then((value) {
      if (value != null) {
        taxList = value;
      }
    });

    await FireStoreUtils().getRazorPayDemo();
    await FireStoreUtils.getPaypalSettingData();
    await FireStoreUtils.getStripeSettingData();
    await FireStoreUtils.getPayStackSettingData();
    await FireStoreUtils.getFlutterWaveSettingData();
    await FireStoreUtils.getPaytmSettingData();
    await FireStoreUtils.getWalletSettingData();
    await FireStoreUtils.getPayFastSettingData();
    await FireStoreUtils.getMercadoPagoSettingData();
    await FireStoreUtils.getReferralAmount();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    cartDatabase = Provider.of<CartDatabase>(context);
  }

  DateTime preBackpress = DateTime.now();

  @override
  Widget build(BuildContext context) {
    final themeChange = Provider.of<DarkThemeProvider>(context);

    return WillPopScope(
      onWillPop: () async {
        if (!(_currentWidget is HomeScreen)) {
          setState(() {
            _drawerSelection = DrawerSelection.Home;
            _appBarTitle = 'Stores'.tr();

            _currentWidget = HomeScreen(
              user: MyAppState.currentUser,
            );
          });
          return false;
        } else {
          final timegap = DateTime.now().difference(preBackpress);
          final cantExit = timegap >= Duration(seconds: 2);
          preBackpress = DateTime.now();
          if (cantExit) {
            final snack = SnackBar(
              content: Text(
                'Press Back button again to Exit'.tr(),
                style: TextStyle(color: Colors.white),
              ),
              duration: Duration(seconds: 2),
              backgroundColor: Colors.black,
            );
            ScaffoldMessenger.of(context).showSnackBar(snack);
            return false; // false will do nothing when back press
          } else {
            return true; // true will exit the app
          }
        }
      },
      child: ChangeNotifierProvider.value(
        value: user,
        child: Consumer<User>(
          builder: (context, user, _) {
            return Scaffold(
              extendBodyBehindAppBar:
                  _drawerSelection == DrawerSelection.Wallet ? true : false,
              key: key,
              drawer: Drawer(
                child: Container(
                    color:
                        isDarkMode(context) ? Color(DARK_VIEWBG_COLOR) : null,
                    child: Column(
                      children: [
                        Expanded(
                          child: ListView(
                            padding: EdgeInsets.zero,
                            children: [
                              Consumer<User>(builder: (context, user, _) {
                                return DrawerHeader(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      displayCircleImage(
                                          user.profilePictureURL, 75, false),
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          top: 8.0),
                                                  child: Text(
                                                    user.fullName(),
                                                    style: const TextStyle(
                                                        color: Colors.white),
                                                  ),
                                                ),
                                                Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 5.0),
                                                    child: Text(
                                                      user.email,
                                                      style: const TextStyle(
                                                          color: Colors.white),
                                                    )),
                                              ],
                                            ),
                                          ),
                                          Row(
                                            children: [
                                              !themeChange.darkTheme
                                                  ? const Icon(
                                                      Icons.light_mode_sharp)
                                                  : const Icon(
                                                      Icons.nightlight),
                                              Transform.scale(
                                                scale: 0.8,
                                                child: CupertinoSwitch(
                                                  // thumb color (round icon)
                                                  // splashRadius: 50.0,
                                                  // activeThumbImage: const AssetImage('https://lists.gnu.org/archive/html/emacs-devel/2015-10/pngR9b4lzUy39.png'),
                                                  // inactiveThumbImage: const AssetImage('http://wolfrosch.com/_img/works/goodies/icon/vim@2x'),

                                                  value: themeChange.darkTheme,
                                                  trackColor: Colors.white,
                                                  onChanged: (value) =>
                                                      setState(() => themeChange
                                                          .darkTheme = value),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                  decoration: BoxDecoration(
                                    color: Color(COLOR_PRIMARY),
                                  ),
                                );
                              }),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                  selected:
                                      _drawerSelection == DrawerSelection.Home,
                                  title: Text('Stores').tr(),
                                  onTap: () {
                                    Navigator.pop(context);
                                    setState(() {
                                      _drawerSelection = DrawerSelection.Home;
                                      _appBarTitle = 'Stores'.tr();

                                      _currentWidget = HomeScreen(
                                        user: MyAppState.currentUser,
                                      );
                                    });
                                  },
                                  leading: Icon(CupertinoIcons.home),
                                ),
                              ),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                    selected: _drawerSelection ==
                                        DrawerSelection.Cuisines,
                                    leading: Icon(Icons.category_outlined),
                                    title: Text('Categories').tr(),
                                    onTap: () {
                                      Navigator.pop(context);
                                      setState(() {
                                        _drawerSelection =
                                            DrawerSelection.Cuisines;
                                        _appBarTitle = 'Categories'.tr();
                                        _currentWidget = CuisinesScreen();
                                      });
                                    }),
                              ),
                              !isDineInEnable
                                  ? Container()
                                  : ListTileTheme(
                                      style: ListTileStyle.drawer,
                                      selectedColor: Color(COLOR_PRIMARY),
                                      child: ListTile(
                                          selected: _drawerSelection ==
                                              DrawerSelection.dineIn,
                                          leading: Icon(Icons.restaurant),
                                          title: Text('Dine-in').tr(),
                                          onTap: () {
                                            Navigator.pop(context);
                                            setState(() {
                                              _drawerSelection =
                                                  DrawerSelection.dineIn;
                                              _appBarTitle = 'Dine-In'.tr();
                                              _currentWidget = DineInScreen(
                                                user: MyAppState.currentUser,
                                              );
                                            });
                                          }),
                                    ),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                    selected: _drawerSelection ==
                                        DrawerSelection.Search,
                                    title: Text('Search').tr(),
                                    leading: Icon(Icons.search),
                                    onTap: () async {
                                      key.currentState!.openEndDrawer();
                                      push(context, const SearchScreen());
                                    }),
                              ),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                  selected: _drawerSelection ==
                                      DrawerSelection.LikedRestaurant,
                                  title: Text('Favourite Stores').tr(),
                                  onTap: () {
                                    if (MyAppState.currentUser == null) {
                                      Navigator.pop(context);
                                      push(context, AuthScreen());
                                    } else {
                                      Navigator.pop(context);
                                      setState(() {
                                        _drawerSelection =
                                            DrawerSelection.LikedRestaurant;
                                        _appBarTitle = 'Favourite Stores'.tr();
                                        _currentWidget =
                                            FavouriteRestaurantScreen();
                                      });
                                    }
                                  },
                                  leading: Icon(CupertinoIcons.heart),
                                ),
                              ),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                  selected: _drawerSelection ==
                                      DrawerSelection.LikedProduct,
                                  title: const Text('Favourite Item').tr(),
                                  onTap: () {
                                    Navigator.pop(context);
                                    if (MyAppState.currentUser == null) {
                                      push(context, AuthScreen());
                                    } else {
                                      setState(() {
                                        _drawerSelection =
                                            DrawerSelection.LikedProduct;
                                        _appBarTitle = 'Favourite Item'.tr();
                                        _currentWidget =
                                            const FavouriteItemScreen();
                                      });
                                    }
                                  },
                                  leading: const Icon(CupertinoIcons.heart),
                                ),
                              ),
                              Visibility(
                                visible:
                                    UserPreference.getWalletData() ?? false,
                                child: ListTileTheme(
                                  style: ListTileStyle.drawer,
                                  selectedColor: Color(COLOR_PRIMARY),
                                  child: ListTile(
                                    selected: _drawerSelection ==
                                        DrawerSelection.Wallet,
                                    leading: Icon(
                                        Icons.account_balance_wallet_outlined),
                                    title: Text('Wallet').tr(),
                                    onTap: () {
                                      if (MyAppState.currentUser == null) {
                                        Navigator.pop(context);
                                        push(context, AuthScreen());
                                      } else {
                                        Navigator.pop(context);
                                        setState(() {
                                          _drawerSelection =
                                              DrawerSelection.Wallet;
                                          _appBarTitle = 'Wallet'.tr();
                                          _currentWidget = WalletScreen();
                                        });
                                      }
                                    },
                                  ),
                                ),
                              ),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                    selected: _drawerSelection ==
                                        DrawerSelection.giftCard,
                                    title: Text('Gift Card').tr(),
                                    leading: Icon(Icons.card_giftcard),
                                    onTap: () async {
                                      key.currentState!.openEndDrawer();
                                      push(context, const GiftCardScreen());
                                    }),
                              ),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                  selected:
                                      _drawerSelection == DrawerSelection.Cart,
                                  leading: Icon(CupertinoIcons.cart),
                                  title: Text('Cart').tr(),
                                  onTap: () {
                                    if (MyAppState.currentUser == null) {
                                      Navigator.pop(context);
                                      push(context, AuthScreen());
                                    } else {
                                      Navigator.pop(context);
                                      setState(() {
                                        _drawerSelection = DrawerSelection.Cart;
                                        _appBarTitle = 'Your Cart'.tr();
                                        _currentWidget = CartScreen(
                                          fromContainer: true,
                                        );
                                      });
                                    }
                                  },
                                ),
                              ),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                  selected: _drawerSelection ==
                                      DrawerSelection.Profile,
                                  leading: Icon(CupertinoIcons.person),
                                  title: Text('Profile').tr(),
                                  onTap: () {
                                    if (MyAppState.currentUser == null) {
                                      Navigator.pop(context);
                                      push(context, AuthScreen());
                                    } else {
                                      Navigator.pop(context);
                                      setState(() {
                                        _drawerSelection =
                                            DrawerSelection.Profile;
                                        _appBarTitle = 'My Profile'.tr();
                                        _currentWidget = ProfileScreen(
                                          user: user,
                                        );
                                      });
                                    }
                                  },
                                ),
                              ),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                  selected: _drawerSelection ==
                                      DrawerSelection.Orders,
                                  leading: Image.asset(
                                    'assets/images/truck.png',
                                    color: _drawerSelection ==
                                            DrawerSelection.Orders
                                        ? Color(COLOR_PRIMARY)
                                        : isDarkMode(context)
                                            ? Colors.grey.shade200
                                            : Colors.grey.shade600,
                                    width: 24,
                                    height: 24,
                                  ),
                                  title: Text('Orders').tr(),
                                  onTap: () {
                                    if (MyAppState.currentUser == null) {
                                      Navigator.pop(context);
                                      push(context, AuthScreen());
                                    } else {
                                      Navigator.pop(context);
                                      setState(() {
                                        _drawerSelection =
                                            DrawerSelection.Orders;
                                        _appBarTitle = 'Orders'.tr();
                                        _currentWidget = OrdersScreen();
                                      });
                                    }
                                  },
                                ),
                              ),
                              !isDineInEnable
                                  ? Container()
                                  : ListTileTheme(
                                      style: ListTileStyle.drawer,
                                      selectedColor: Color(COLOR_PRIMARY),
                                      child: ListTile(
                                        selected: _drawerSelection ==
                                            DrawerSelection.MyBooking,
                                        leading: Image.asset(
                                          'assets/images/your_booking.png',
                                          color: _drawerSelection ==
                                                  DrawerSelection.MyBooking
                                              ? Color(COLOR_PRIMARY)
                                              : isDarkMode(context)
                                                  ? Colors.grey.shade200
                                                  : Colors.grey.shade600,
                                          width: 24,
                                          height: 24,
                                        ),
                                        title: Text('Dine-In Bookings').tr(),
                                        onTap: () {
                                          if (MyAppState.currentUser == null) {
                                            Navigator.pop(context);
                                            push(context, AuthScreen());
                                          } else {
                                            Navigator.pop(context);
                                            setState(() {
                                              _drawerSelection =
                                                  DrawerSelection.MyBooking;
                                              _appBarTitle =
                                                  'Dine-In Bookings'.tr();
                                              _currentWidget =
                                                  MyBookingScreen();
                                            });
                                          }
                                        },
                                      ),
                                    ),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                  selected: _drawerSelection ==
                                      DrawerSelection.referral,
                                  leading: Image.asset(
                                    'assets/images/refer.png',
                                    width: 28,
                                    color: Colors.grey,
                                  ),
                                  title: const Text('Refer a friend').tr(),
                                  onTap: () async {
                                    if (MyAppState.currentUser == null) {
                                      Navigator.pop(context);
                                      push(context, AuthScreen());
                                    } else {
                                      Navigator.pop(context);
                                      push(context, ReferralScreen());
                                    }
                                  },
                                ),
                              ),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                  selected: _drawerSelection ==
                                      DrawerSelection.chooseLanguage,
                                  leading: Icon(
                                    Icons.language,
                                    color: _drawerSelection ==
                                            DrawerSelection.chooseLanguage
                                        ? Color(COLOR_PRIMARY)
                                        : isDarkMode(context)
                                            ? Colors.grey.shade200
                                            : Colors.grey.shade600,
                                  ),
                                  title: const Text('Language').tr(),
                                  onTap: () {
                                    Navigator.pop(context);
                                    setState(() {
                                      _drawerSelection =
                                          DrawerSelection.chooseLanguage;
                                      _appBarTitle = 'Language'.tr();
                                      _currentWidget = LanguageChooseScreen(
                                        isContainer: true,
                                      );
                                    });
                                  },
                                ),
                              ),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                  selected:
                                      _drawerSelection == DrawerSelection.inbox,
                                  leading:
                                      Icon(CupertinoIcons.chat_bubble_2_fill),
                                  title: Text('Stores Inbox').tr(),
                                  onTap: () {
                                    if (MyAppState.currentUser == null) {
                                      Navigator.pop(context);
                                      push(context, AuthScreen());
                                    } else {
                                      Navigator.pop(context);
                                      setState(() {
                                        _drawerSelection =
                                            DrawerSelection.inbox;
                                        _appBarTitle = 'Stores Inbox'.tr();
                                        _currentWidget = InboxScreen();
                                      });
                                    }
                                  },
                                ),
                              ),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                  selected: _drawerSelection ==
                                      DrawerSelection.driver,
                                  leading:
                                      Icon(CupertinoIcons.chat_bubble_2_fill),
                                  title: Text('Driver Inbox').tr(),
                                  onTap: () {
                                    if (MyAppState.currentUser == null) {
                                      Navigator.pop(context);
                                      push(context, AuthScreen());
                                    } else {
                                      Navigator.pop(context);
                                      setState(() {
                                        _drawerSelection =
                                            DrawerSelection.driver;
                                        _appBarTitle = 'Driver Inbox'.tr();
                                        _currentWidget = InboxDriverScreen();
                                      });
                                    }
                                  },
                                ),
                              ),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                  selected: _drawerSelection ==
                                      DrawerSelection.termsCondition,
                                  leading: const Icon(Icons.policy),
                                  title: const Text('Terms and Condition').tr(),
                                  onTap: () async {
                                    push(context, const TermsAndCondition());
                                  },
                                ),
                              ),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                  selected: _drawerSelection ==
                                      DrawerSelection.privacyPolicy,
                                  leading: const Icon(Icons.privacy_tip),
                                  title: const Text('Privacy policy').tr(),
                                  onTap: () async {
                                    push(context, const PrivacyPolicyScreen());
                                  },
                                ),
                              ),
                              ListTileTheme(
                                style: ListTileStyle.drawer,
                                selectedColor: Color(COLOR_PRIMARY),
                                child: ListTile(
                                    selected: _drawerSelection ==
                                        DrawerSelection.Logout,
                                    leading: Icon(Icons.logout),
                                    title: Text(MyAppState.currentUser == null
                                            ? 'Login'.tr()
                                            : 'Log Out'.tr())
                                        ,
                                    onTap: () async {
                                      if (MyAppState.currentUser == null) {
                                        pushAndRemoveUntil(
                                            context, AuthScreen(), false);
                                      } else {
                                        Navigator.pop(context);
                                        //user.active = false;
                                        user.lastOnlineTimestamp =
                                            Timestamp.now();
                                        user.fcmToken = "";
                                        await FireStoreUtils.updateCurrentUser(
                                            user);
                                        await auth.FirebaseAuth.instance
                                            .signOut();
                                        MyAppState.currentUser = null;
                                        Provider.of<CartDatabase>(context,
                                                listen: false)
                                            .deleteAllProducts();
                                        pushAndRemoveUntil(
                                            context, AuthScreen(), false);
                                      }
                                    }),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text("V : $appVersion"),
                        )
                      ],
                    )),
              ),
              appBar: AppBar(
                elevation: 0,
                centerTitle:
                    _drawerSelection == DrawerSelection.Wallet ? true : false,
                backgroundColor: _drawerSelection == DrawerSelection.Wallet
                    ? Colors.transparent
                    : isDarkMode(context)
                        ? Color(DARK_COLOR)
                        : _drawerSelection == DrawerSelection.Home
                            ? Colors.black
                            : Colors.white,
                //isDarkMode(context) ? Color(DARK_COLOR) : null,
                leading: IconButton(
                    visualDensity: VisualDensity(horizontal: -4),
                    padding: EdgeInsets.only(right: 5),
                    icon: Image(
                      image: AssetImage("assets/images/menu.png"),
                      width: 20,
                      color: _drawerSelection == DrawerSelection.Wallet
                          ? Colors.white
                          : isDarkMode(context)
                              ? Colors.white
                              : _drawerSelection == DrawerSelection.Home
                                  ? Colors.white
                                  : Colors.black,
                    ),
                    onPressed: () => key.currentState!.openDrawer()),
                // iconTheme: IconThemeData(color: Colors.blue),
                title: Text(
                  _appBarTitle,
                  style: TextStyle(
                      fontFamily: "Poppinsm",
                      color: isDarkMode(context)
                          ? Colors.white
                          : _drawerSelection == DrawerSelection.Home
                              ? Colors.white
                              : Colors.black,
                      //isDarkMode(context) ? Colors.white : Colors.black,
                      fontWeight: FontWeight.normal),
                ),
                actions: _drawerSelection == DrawerSelection.Wallet ||
                        _drawerSelection == DrawerSelection.MyBooking
                    ? []
                    : _drawerSelection == DrawerSelection.dineIn
                        ? [
                            IconButton(
                                padding: const EdgeInsets.only(right: 20),
                                visualDensity: VisualDensity(horizontal: -4),
                                tooltip: 'QrCode'.tr(),
                                icon: Image(
                                  image: AssetImage("assets/images/qrscan.png"),
                                  width: 20,
                                  color: isDarkMode(context)
                                      ? Colors.white
                                      : _drawerSelection == DrawerSelection.Home
                                          ? Colors.white
                                          : Colors.black,
                                ),
                                onPressed: () {
                                  push(
                                    context,
                                    QrCodeScanner(),
                                  );
                                }),
                            IconButton(
                                visualDensity:
                                    const VisualDensity(horizontal: -4),
                                padding: EdgeInsets.only(right: 10),
                                icon: Image(
                                  image: AssetImage("assets/images/search.png"),
                                  width: 20,
                                  color: isDarkMode(context)
                                      ? Colors.white
                                      : _drawerSelection == DrawerSelection.Home
                                          ? Colors.white
                                          : Colors.black,
                                ),
                                onPressed: () {
                                  setState(() {
                                    push(context, const SearchScreen());
                                  });
                                }),
                            if (!(_currentWidget is CartScreen) ||
                                !(_currentWidget is ProfileScreen))
                              IconButton(
                                visualDensity: VisualDensity(horizontal: -4),
                                padding: EdgeInsets.only(right: 10),
                                icon: Image(
                                  image: AssetImage("assets/images/map.png"),
                                  width: 20,
                                  color: isDarkMode(context)
                                      ? Colors.white
                                      : _drawerSelection == DrawerSelection.Home
                                          ? Colors.white
                                          : Colors.black,
                                ),
                                onPressed: () => push(
                                  context,
                                  MapViewScreen(),
                                ),
                              )
                          ]
                        : [
                            IconButton(
                                padding: const EdgeInsets.only(right: 20),
                                visualDensity: VisualDensity(horizontal: -4),
                                tooltip: 'QrCode'.tr(),
                                icon: Stack(
                                  clipBehavior: Clip.none,
                                  children: [
                                    Image(
                                      image: AssetImage(
                                          "assets/images/qrscan.png"),
                                      width: 20,
                                      color: isDarkMode(context)
                                          ? Colors.white
                                          : _drawerSelection ==
                                                  DrawerSelection.Home
                                              ? Colors.white
                                              : Colors.black,
                                    ),
                                  ],
                                ),
                                onPressed: () {
                                  push(
                                    context,
                                    QrCodeScanner(),
                                  );
                                }),
                            IconButton(
                                visualDensity:
                                    const VisualDensity(horizontal: -4),
                                padding: EdgeInsets.only(right: 10),
                                icon: Image(
                                  image: AssetImage("assets/images/search.png"),
                                  width: 20,
                                  color: isDarkMode(context)
                                      ? Colors.white
                                      : _drawerSelection == DrawerSelection.Home
                                          ? Colors.white
                                          : Colors.black,
                                ),
                                onPressed: () {
                                  push(context, const SearchScreen());
                                }),
                            if (!(_currentWidget is CartScreen) ||
                                !(_currentWidget is ProfileScreen))
                              IconButton(
                                visualDensity: VisualDensity(horizontal: -4),
                                padding: EdgeInsets.only(right: 10),
                                icon: Image(
                                  image: AssetImage("assets/images/map.png"),
                                  width: 20,
                                  color: isDarkMode(context)
                                      ? Colors.white
                                      : _drawerSelection == DrawerSelection.Home
                                          ? Colors.white
                                          : Colors.black,
                                ),
                                onPressed: () => push(
                                  context,
                                  MapViewScreen(),
                                ),
                              ),
                            if (!(_currentWidget is CartScreen) ||
                                !(_currentWidget is ProfileScreen))
                              IconButton(
                                  padding: EdgeInsets.only(right: 20),
                                  visualDensity: VisualDensity(horizontal: -4),
                                  tooltip: 'Cart'.tr(),
                                  icon: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Image(
                                        image: AssetImage(
                                            "assets/images/cart.png"),
                                        width: 20,
                                        color: isDarkMode(context)
                                            ? Colors.white
                                            : _drawerSelection ==
                                                    DrawerSelection.Home
                                                ? Colors.white
                                                : Colors.black,
                                      ),
                                      StreamBuilder<List<CartProduct>>(
                                        stream: cartDatabase.watchProducts,
                                        builder: (context, snapshot) {
                                          cartCount = 0;
                                          if (snapshot.hasData) {
                                            snapshot.data!.forEach((element) {
                                              cartCount += element.quantity;
                                            });
                                          }
                                          return Visibility(
                                            visible: cartCount >= 1,
                                            child: Positioned(
                                              right: -6,
                                              top: -8,
                                              child: Container(
                                                padding: EdgeInsets.all(4),
                                                decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: Color(COLOR_PRIMARY),
                                                ),
                                                constraints: BoxConstraints(
                                                  minWidth: 12,
                                                  minHeight: 12,
                                                ),
                                                child: Center(
                                                  child: new Text(
                                                    cartCount <= 99
                                                        ? '$cartCount'
                                                        : '+99',
                                                    style: new TextStyle(
                                                      color: Colors.white,
                                                      // fontSize: 10,
                                                    ),
                                                    textAlign: TextAlign.center,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          );
                                        },
                                      )
                                    ],
                                  ),
                                  onPressed: () {
                                    if (MyAppState.currentUser == null) {
                                      Navigator.pop(context);
                                      push(context, AuthScreen());
                                    } else {
                                      setState(() {
                                        _drawerSelection = DrawerSelection.Cart;
                                        _appBarTitle = 'Your Cart'.tr();
                                        _currentWidget = CartScreen(
                                          fromContainer: true,
                                        );
                                      });
                                    }
                                  }),
                          ],
              ),
              body: _currentWidget,
            );
          },
        ),
      ),
    );
  }
}
